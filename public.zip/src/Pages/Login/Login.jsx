import "./Login.scss"

const Login = () => {
  return (
    <div className="Login">
        <h1>GULAM</h1>
    </div>
  )
}

export default Login