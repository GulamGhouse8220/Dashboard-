import "./New.scss"

const New = () => {
  return (
    <div className="New">New</div>
  )
}

export default New