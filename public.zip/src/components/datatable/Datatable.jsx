import "./datatable.scss"
import { DataGrid } from '@mui/x-data-grid';
import { userColumns , userRows } from "../../datatablesources";


const Datatable = () => {
    const actionColumn = [{field: "action", headName: "Action", width: 200, renderCell:()=>{
        return(
        <div className="cellAction">
            <div className="viewButton">View</div>
            <div className="deleteButton">Delete</div>
        </div>
        )
    }}];
  return (
    <div className="dataTable">
         <DataGrid
        rows={userRows}
        columns={userColumns.concat(actionColumn)}
        pageSize={7}
        rowsPerPageOptions={[7]}
        checkboxSelection
      />
    </div>
  )
}

export default Datatable