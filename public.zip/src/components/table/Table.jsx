import "./table.scss"
import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';

function createData(name, product, customer, date, amount, paymentmethod, status, image) {
  return { name, product, customer, date, amount, paymentmethod, status, image};
}

const rows = [
  createData('556321', 'Zebronics', 'KinGulam', '19-Apr-2000', 500, 'Cash on Delivery', 'Pending',"download (1).jpg"),
  createData('442215', 'Dell', 'Bala', '02-Jan-1998', 499, 'Online Delivery', 'Pending', "DSC_1148_1637376990850_1637377001492.jpg"),
  createData('779964', 'Thinkpad', 'Nagraj', '19-Jun-1999', 450, 'Cash on Delivery', 'Approved', "images (3).jpg"),
  createData('236541', 'Dell', 'Akash', '18-Feb-1999', 489, 'Online', 'Approved', "pexels-photo-811587.webp"),
  createData('963245', 'Thinkpad', 'Thangadurai', '27-Aug-1998', 350, 'Online', 'Approved', "images.jpg"),
];

export default function BasicTable() {
  return (
    <TableContainer component={Paper} className="table">
        <div className="table"></div>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell>Traiking ID</TableCell>
            <TableCell className="tableCell">Product</TableCell>
            <TableCell className="tableCell">customer</TableCell>
            <TableCell className="tableCell">Date</TableCell>
            <TableCell className="tableCell">Amount</TableCell>
            <TableCell className="tableCell">Payment Method</TableCell>
            <TableCell className="tableCell">Status</TableCell>

          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <TableRow
              key={row.name}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell component="th" scope="row">
                {row.name}
              </TableCell>
              <TableCell className="tableCell">
                <div className="cellwrapper">
                  <img src={row.image} className="image" />
                  {row.product}
                </div>
              </TableCell>
              <TableCell className="tableCell">{row.customer}</TableCell>
              <TableCell className="tableCell">{row.date}</TableCell>
              <TableCell className="tableCell">{row.amount}</TableCell>
              <TableCell className="tableCell">{row.paymentmethod}</TableCell>
              <TableCell className="tableCell">
                <span className={`status ${row.status}`}>{row.status}</span>
              </TableCell>

            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}